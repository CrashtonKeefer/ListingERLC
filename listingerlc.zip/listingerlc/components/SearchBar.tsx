"use client";

import { Search } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  tags: string[];
  activeTag: string | null;
  onTagSelect: (tag: string | null) => void;
}

export function SearchBar({ value, onChange, placeholder, tags, activeTag, onTagSelect }: SearchBarProps) {
  return (
    <div>
      <div className="flex items-center gap-3 rounded-2xl border border-line bg-panel/60 px-5 py-4">
        <Search size={18} className="text-mute" />
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full bg-transparent font-body text-sm text-paper placeholder:text-mute focus:outline-none"
        />
        <Button size="sm">Search</Button>
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
        <span className="font-mono text-xs uppercase tracking-wider text-mute">Try:</span>
        {tags.map((tag) => (
          <button
            key={tag}
            onClick={() => onTagSelect(activeTag === tag ? null : tag)}
            className={cn(
              "rounded-full border px-3 py-1 font-mono text-xs uppercase tracking-wide transition-colors",
              activeTag === tag
                ? "border-accent-blue/60 bg-accent-blue/10 text-accent-blue"
                : "border-line text-mute hover:text-paper"
            )}
          >
            {tag}
          </button>
        ))}
      </div>
    </div>
  );
}
