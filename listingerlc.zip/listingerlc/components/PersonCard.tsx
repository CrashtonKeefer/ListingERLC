import { RatingStars } from "@/components/ui/RatingStars";
import { Button } from "@/components/ui/Button";
import type { Person } from "@/lib/data";
import { cn } from "@/lib/utils";

export function PersonCard({ person }: { person: Person }) {
  return (
    <div className="group relative rounded-2xl border border-line bg-panel/50 p-5 transition-colors hover:bg-panel2">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-line bg-panel2 font-display text-sm font-bold uppercase">
            {person.handle.slice(0, 2)}
          </div>
          <div>
            <h3 className="font-display text-lg font-bold leading-tight tracking-tight">{person.handle}</h3>
            <div className="mt-0.5 flex items-center gap-3 text-xs text-mute">
              <span>{person.role}</span>
              <RatingStars rating={person.rating} />
            </div>
          </div>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider",
            person.available ? "bg-accent-green/15 text-accent-green" : "bg-mute/15 text-mute"
          )}
        >
          {person.available ? "Available" : "Booked"}
        </span>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-mute">{person.bio}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {person.skills.map((skill) => (
          <span key={skill} className="rounded-full border border-line px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-mute">
            {skill}
          </span>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-line pt-4">
        <span className="font-mono text-xs text-paper">{person.rate}</span>
        <Button size="sm" variant="discord" disabled={!person.available}>
          Message on Discord
        </Button>
      </div>
    </div>
  );
}
