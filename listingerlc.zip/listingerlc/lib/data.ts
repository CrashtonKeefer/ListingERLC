export type Server = {
  id: string;
  name: string;
  tag: string;
  rating: number;
  members: number;
  description: string;
  tags: string[];
  badge?: "Featured" | "New";
  bumps: number;
  discordUrl: string;
  playUrl: string;
  accent: "blue" | "red" | "amber" | "green";
};

export const SERVERS: Server[] = [
  {
    id: "harborview-rp",
    name: "Harborview Roleplay",
    tag: "HRP",
    rating: 4.8,
    members: 7400,
    description:
      "A serious, story-driven Liberty County community with active PD, FD and EMS departments and a strict no-drama policy.",
    tags: ["Roleplay", "Serious", "Active staff"],
    badge: "Featured",
    bumps: 412,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "blue",
  },
  {
    id: "lakeshore-county",
    name: "Lakeshore County RP",
    tag: "LCRP",
    rating: 4.6,
    members: 5100,
    description:
      "Civilian-first roleplay with a full custom dispatch system and weekly community events.",
    tags: ["Roleplay", "Civilian", "Events"],
    badge: "Featured",
    bumps: 388,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "amber",
  },
  {
    id: "midcity-emergency",
    name: "Midcity Emergency Network",
    tag: "MEN",
    rating: 4.3,
    members: 3200,
    description:
      "Realistic dispatch training, ride-along program for new members, and a friendly, low-pressure staff team.",
    tags: ["Training", "Beginner friendly"],
    badge: "New",
    bumps: 96,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "green",
  },
  {
    id: "redline-county",
    name: "Redline County RP",
    tag: "RCRP",
    rating: 4.1,
    members: 2150,
    description:
      "Pursuit-focused roleplay with custom liveries and a dedicated state patrol division.",
    tags: ["Pursuits", "State Patrol"],
    bumps: 210,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "red",
  },
  {
    id: "brookline-rp",
    name: "Brookline City RP",
    tag: "BCRP",
    rating: 4.0,
    members: 1840,
    description:
      "Small but tight-knit community focused on slow-burn, realistic storylines over fast pursuits.",
    tags: ["Roleplay", "Story-driven"],
    bumps: 154,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "blue",
  },
  {
    id: "ironcreek-pd",
    name: "Iron Creek PD Network",
    tag: "ICPD",
    rating: 4.5,
    members: 4300,
    description:
      "PD-focused community with structured rank progression and monthly FTO evaluations.",
    tags: ["PD focused", "Structured"],
    bumps: 301,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "amber",
  },
  {
    id: "sundale-county",
    name: "Sundale County RP",
    tag: "SCRP",
    rating: 3.9,
    members: 980,
    description:
      "New community looking for founding members — open staff applications and flexible department choice.",
    tags: ["New", "Hiring staff"],
    badge: "New",
    bumps: 41,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "green",
  },
  {
    id: "westport-county",
    name: "Westport County RP",
    tag: "WCRP",
    rating: 4.4,
    members: 2900,
    description:
      "Drama-free environment with an emphasis on realistic radio etiquette and call procedures.",
    tags: ["Drama-free", "Radio etiquette"],
    bumps: 188,
    discordUrl: "https://discord.gg/replace-me",
    playUrl: "#",
    accent: "red",
  },
];

export type Person = {
  id: string;
  handle: string;
  role: string;
  rating: number;
  rate: string;
  bio: string;
  skills: string[];
  available: boolean;
  discordUrl: string;
};

export const PEOPLE: Person[] = [
  {
    id: "p1",
    handle: "nova.dev",
    role: "Builder",
    rating: 4.9,
    rate: "Robux \u00b7 negotiable",
    bio: "Builds custom PD/FD stations and city blocks. Portfolio of 12+ Liberty County maps.",
    skills: ["Building", "Terrain", "Optimization"],
    available: true,
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "p2",
    handle: "kestrel_scripts",
    role: "Scripter",
    rating: 4.7,
    rate: "$15\u2013$30 / task",
    bio: "Builds custom dispatch systems, ticket bots, and ER:LC-integrated tools.",
    skills: ["Lua", "Dispatch systems", "Discord bots"],
    available: true,
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "p3",
    handle: "marrow_mod",
    role: "Moderator",
    rating: 4.8,
    rate: "Volunteer / paid",
    bio: "5 years moderating large roleplay servers. Calm under pressure, fair with rule enforcement.",
    skills: ["Moderation", "Conflict resolution", "Staff training"],
    available: false,
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "p4",
    handle: "glasswing.gfx",
    role: "Graphic Designer",
    rating: 4.6,
    rate: "$10\u2013$25 / piece",
    bio: "Server banners, logos, livery templates, and animated Discord emojis.",
    skills: ["Logo design", "Liveries", "Motion graphics"],
    available: true,
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "p5",
    handle: "static.va",
    role: "Voice Actor",
    rating: 4.5,
    rate: "Robux \u00b7 negotiable",
    bio: "Dispatch and announcement voice lines, multiple tones available.",
    skills: ["Voice acting", "Dispatch lines"],
    available: true,
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "p6",
    handle: "ledger.cm",
    role: "Community Manager",
    rating: 4.4,
    rate: "Salaried \u00b7 negotiable",
    bio: "Ran growth and events for a 6k-member community. Strong with onboarding flows.",
    skills: ["Growth", "Events", "Onboarding"],
    available: false,
    discordUrl: "https://discord.gg/replace-me",
  },
];

export type Job = {
  id: string;
  server: string;
  role: string;
  type: "Volunteer" | "Paid";
  compensation: string;
  description: string;
  postedAgo: string;
  discordUrl: string;
};

export const JOBS: Job[] = [
  {
    id: "j1",
    server: "Harborview Roleplay",
    role: "Lead Scripter",
    type: "Paid",
    compensation: "$200\u2013$400 / project",
    description:
      "Looking for an experienced scripter to build a custom EMS dispatch board with live unit tracking.",
    postedAgo: "2h ago",
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "j2",
    server: "Lakeshore County RP",
    role: "Moderator",
    type: "Volunteer",
    compensation: "In-game perks",
    description:
      "Need 2 more trial moderators for EU timezone coverage. Must be 16+ and active 10+ hrs/week.",
    postedAgo: "6h ago",
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "j3",
    server: "Iron Creek PD Network",
    role: "Builder",
    type: "Paid",
    compensation: "Robux \u00b7 negotiable",
    description:
      "Commissioning a new precinct interior and impound lot. Send portfolio when applying.",
    postedAgo: "11h ago",
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "j4",
    server: "Sundale County RP",
    role: "Community Manager",
    type: "Volunteer",
    compensation: "Founding staff equity",
    description:
      "Brand-new server looking for a founding community manager to help shape culture and events from day one.",
    postedAgo: "1d ago",
    discordUrl: "https://discord.gg/replace-me",
  },
  {
    id: "j5",
    server: "Westport County RP",
    role: "Graphic Designer",
    type: "Paid",
    compensation: "$15\u2013$25 / piece",
    description:
      "Need a full rebrand: new logo, banner set, and livery templates for 6 vehicle classes.",
    postedAgo: "1d ago",
    discordUrl: "https://discord.gg/replace-me",
  },
];
