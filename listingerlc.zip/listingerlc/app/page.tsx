"use client";

import { useMemo, useState } from "react";
import { Radio } from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SearchBar } from "@/components/SearchBar";
import { ServerCard } from "@/components/ServerCard";
import { AdSpot } from "@/components/AdSpot";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { SERVERS } from "@/lib/data";

const FILTER_TAGS = ["Roleplay", "Serious", "Beginner friendly", "Drama-free", "Hiring staff"];

export default function DiscoverPage() {
  const [query, setQuery] = useState("");
  const [activeTag, setActiveTag] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return SERVERS.filter((s) => {
      const matchesQuery =
        query.trim().length === 0 ||
        s.name.toLowerCase().includes(query.toLowerCase()) ||
        s.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()));
      const matchesTag = !activeTag || s.tags.includes(activeTag);
      return matchesQuery && matchesTag;
    });
  }, [query, activeTag]);

  const featured = SERVERS.filter((s) => s.badge === "Featured");
  const fresh = [...SERVERS].filter((s) => s.badge === "New").concat(
    [...SERVERS].sort((a, b) => b.bumps - a.bumps).slice(0, 3)
  );
  const popular = [...SERVERS].sort((a, b) => b.bumps - a.bumps);

  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <Navbar />

      <section className="relative overflow-hidden pt-32 pb-16 md:pt-40">
        <div className="pointer-events-none absolute inset-0 bg-grid-fade" />
        <div className="relative mx-auto max-w-4xl px-6 text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-line bg-panel/60 px-4 py-1.5 font-mono text-xs uppercase tracking-[0.2em] text-mute">
            <Radio size={13} className="animate-pulse-dot text-accent-green" />
            312 servers listed
          </div>

          <h1 className="font-display text-5xl font-bold uppercase leading-[1] tracking-tight sm:text-6xl md:text-7xl">
            Discover <span className="text-gradient-badge">ER:LC</span> servers.
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-mute md:text-lg">
            Browse Liberty County roleplay communities, hire builders and scripters, or find your
            next staff role — all linked straight to Discord.
          </p>

          <div className="mx-auto mt-9 max-w-2xl">
            <SearchBar
              value={query}
              onChange={setQuery}
              placeholder="Search servers, tags, or owners"
              tags={FILTER_TAGS}
              activeTag={activeTag}
              onTagSelect={setActiveTag}
            />
          </div>
        </div>
      </section>

      <section className="relative border-t border-line py-16">
        <div className="mx-auto max-w-6xl px-6">
          <SectionLabel>Featured</SectionLabel>
          <h2 className="mt-3 font-display text-3xl font-bold uppercase tracking-tight">
            {query || activeTag ? `Results (${filtered.length})` : "Featured this week"}
          </h2>

          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {(query || activeTag ? filtered : featured).map((server) => (
              <ServerCard key={server.id} server={server} />
            ))}
            {(query || activeTag) && filtered.length === 0 && (
              <p className="col-span-full text-center text-sm text-mute">
                No servers match that search. Try a different tag.
              </p>
            )}
          </div>

          <div className="mt-8">
            <AdSpot />
          </div>
        </div>
      </section>

      {!query && !activeTag && (
        <section className="relative border-t border-line py-16">
          <div className="mx-auto max-w-6xl px-6">
            <div className="grid gap-12 lg:grid-cols-[1fr_320px]">
              <div>
                <SectionLabel>Popular</SectionLabel>
                <h2 className="mt-3 font-display text-3xl font-bold uppercase tracking-tight">
                  Trending this week
                </h2>
                <div className="mt-8 grid gap-5 sm:grid-cols-2">
                  {popular.slice(0, 4).map((server) => (
                    <ServerCard key={server.id} server={server} />
                  ))}
                </div>
              </div>

              <div>
                <SectionLabel>New servers</SectionLabel>
                <div className="mt-3 flex flex-col gap-3 rounded-2xl border border-line bg-panel/40 p-3">
                  {fresh.slice(0, 5).map((server, i) => (
                    <div key={server.id} className="flex items-center gap-3 rounded-xl p-2 transition-colors hover:bg-panel2">
                      <span className="w-5 font-mono text-xs text-mute">{String(i + 1).padStart(2, "0")}</span>
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-line bg-panel2 font-display text-xs font-bold uppercase">
                        {server.tag}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate font-body text-sm font-medium text-paper">{server.name}</p>
                        <p className="font-mono text-[10px] uppercase tracking-wide text-mute">
                          {server.badge ?? "Active"} · {server.members.toLocaleString()} members
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
