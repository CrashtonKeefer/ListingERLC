"use client";

import { useState } from "react";
import { ArrowUp } from "lucide-react";
import { cn } from "@/lib/utils";

export function BumpButton({ initialCount }: { initialCount: number }) {
  const [count, setCount] = useState(initialCount);
  const [bumped, setBumped] = useState(false);

  return (
    <button
      onClick={() => {
        if (bumped) return;
        setCount((c) => c + 1);
        setBumped(true);
      }}
      disabled={bumped}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 font-mono text-xs transition-all duration-200",
        bumped
          ? "border-accent-green/50 bg-accent-green/10 text-accent-green"
          : "border-line text-mute hover:border-accent-blue/50 hover:text-paper"
      )}
    >
      <ArrowUp size={13} className={bumped ? "" : "transition-transform group-hover:-translate-y-0.5"} />
      {count}
    </button>
  );
}
