import { Star } from "lucide-react";

export function RatingStars({ rating }: { rating: number }) {
  return (
    <span className="inline-flex items-center gap-1 font-mono text-xs text-accent-amber">
      <Star size={13} className="fill-accent-amber text-accent-amber" />
      {rating.toFixed(1)}
    </span>
  );
}
