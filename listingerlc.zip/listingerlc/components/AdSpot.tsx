import { Megaphone } from "lucide-react";

export function AdSpot() {
  return (
    <div className="flex flex-col items-start justify-between gap-4 rounded-2xl border border-dashed border-line bg-panel/40 p-5 sm:flex-row sm:items-center">
      <div className="flex items-center gap-4">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-line bg-panel2 text-mute">
          <Megaphone size={18} />
        </div>
        <div>
          <h4 className="font-display text-base font-bold tracking-tight">Want more members?</h4>
          <p className="text-sm text-mute">Advertise your server in this spot and reach the right players.</p>
        </div>
      </div>
      <span className="shrink-0 rounded-full border border-line px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-mute">
        Ad spot
      </span>
    </div>
  );
}
