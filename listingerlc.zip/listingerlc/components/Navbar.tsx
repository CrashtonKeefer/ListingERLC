"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signIn, signOut, useSession } from "next-auth/react";
import { Menu, X, Plus } from "lucide-react";
import { Logo } from "@/components/ui/Logo";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "Discover", href: "/" },
  { label: "People", href: "/people" },
  { label: "Hiring", href: "/hiring" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { data: session } = useSession();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled ? "border-b border-line bg-ink/80 backdrop-blur-md" : "border-b border-transparent bg-transparent"
      )}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2 text-paper">
          <Logo />
          <span className="font-display text-xl font-bold uppercase tracking-tight">
            ListingERLC
          </span>
        </Link>

        <ul className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <Link
                href={link.href}
                className={cn(
                  "font-body text-sm transition-colors hover:text-paper",
                  pathname === link.href ? "text-paper" : "text-mute"
                )}
              >
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 md:flex">
          <Button size="sm" variant="secondary">
            <Plus size={14} />
            Add server
          </Button>
          {session ? (
            <button
              onClick={() => signOut()}
              className="px-3 py-2 text-sm text-mute transition-colors hover:text-paper"
            >
              Sign out
            </button>
          ) : (
            <Button size="sm" variant="discord" onClick={() => signIn("discord")}>
              Sign in with Discord
            </Button>
          )}
        </div>

        <button
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
          className="flex items-center justify-center rounded-full border border-line p-2 text-paper md:hidden"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {open && (
        <div className="border-t border-line bg-ink/95 px-6 py-6 backdrop-blur-md md:hidden">
          <ul className="flex flex-col gap-4">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <Link href={link.href} onClick={() => setOpen(false)} className="block font-body text-base text-paper">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-col gap-3">
            <Button size="md" variant="secondary" className="w-full">
              <Plus size={14} />
              Add server
            </Button>
            {session ? (
              <button onClick={() => signOut()} className="text-center text-sm text-mute">
                Sign out
              </button>
            ) : (
              <Button size="md" variant="discord" className="w-full" onClick={() => signIn("discord")}>
                Sign in with Discord
              </Button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
