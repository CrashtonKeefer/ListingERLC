import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0A0E16",
        panel: "#121724",
        panel2: "#171D2C",
        line: "#FFFFFF14",
        paper: "#F2F4F8",
        mute: "#8B93A6",
        accent: {
          blue: "#3B7BFF",
          red: "#FF4D5E",
          amber: "#FFB800",
          green: "#34D399",
        },
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"],
        mono: ["var(--font-mono)"],
      },
      backgroundImage: {
        "grid-fade":
          "radial-gradient(ellipse 70% 60% at 50% 0%, rgba(59,123,255,0.16), transparent), linear-gradient(to bottom, transparent, #0A0E16 92%), repeating-linear-gradient(0deg, #ffffff07 0px, #ffffff07 1px, transparent 1px, transparent 44px), repeating-linear-gradient(90deg, #ffffff07 0px, #ffffff07 1px, transparent 1px, transparent 44px)",
      },
      boxShadow: {
        "glow-blue": "0 0 22px 0 rgba(59,123,255,0.4)",
        "glow-red": "0 0 22px 0 rgba(255,77,94,0.35)",
        "glow-amber": "0 0 22px 0 rgba(255,184,0,0.35)",
      },
      keyframes: {
        sweep: {
          "0%": { transform: "translateX(-100%)" },
          "100%": { transform: "translateX(200%)" },
        },
        "pulse-dot": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" },
        },
      },
      animation: {
        sweep: "sweep 2.6s ease-in-out infinite",
        "pulse-dot": "pulse-dot 1.8s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
