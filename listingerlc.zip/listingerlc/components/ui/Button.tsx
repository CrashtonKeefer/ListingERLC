"use client";

import { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "discord";
  size?: "sm" | "md" | "lg";
  children: ReactNode;
}

export function Button({
  variant = "primary",
  size = "md",
  className,
  children,
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        "relative inline-flex items-center justify-center gap-2 rounded-full font-body font-semibold tracking-tight transition-all duration-200 ease-out active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none",
        size === "sm" && "px-4 py-2 text-xs",
        size === "md" && "px-6 py-3 text-sm",
        size === "lg" && "px-8 py-4 text-base",
        variant === "primary" && "bg-paper text-ink hover:bg-white hover:shadow-glow-blue",
        variant === "secondary" &&
          "bg-transparent text-paper border border-line hover:border-accent-blue/60 hover:shadow-glow-blue",
        variant === "ghost" && "bg-panel/60 text-paper border border-line hover:bg-panel2",
        variant === "discord" && "bg-[#5865F2] text-white hover:bg-[#4752C4] hover:shadow-glow-blue",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
