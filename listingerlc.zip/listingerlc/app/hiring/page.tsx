"use client";

import { useMemo, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SearchBar } from "@/components/SearchBar";
import { JobCard } from "@/components/JobCard";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { JOBS } from "@/lib/data";

const FILTER_TAGS = ["Paid", "Volunteer", "Scripter", "Builder", "Moderator"];

export default function HiringPage() {
  const [query, setQuery] = useState("");
  const [activeTag, setActiveTag] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return JOBS.filter((j) => {
      const matchesQuery =
        query.trim().length === 0 ||
        j.server.toLowerCase().includes(query.toLowerCase()) ||
        j.role.toLowerCase().includes(query.toLowerCase());
      const matchesTag = !activeTag || j.type === activeTag || j.role === activeTag;
      return matchesQuery && matchesTag;
    });
  }, [query, activeTag]);

  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <Navbar />

      <section className="relative overflow-hidden pt-32 pb-16 md:pt-40">
        <div className="pointer-events-none absolute inset-0 bg-grid-fade" />
        <div className="relative mx-auto max-w-4xl px-6 text-center">
          <SectionLabel className="mx-auto mb-5 w-fit">Hiring</SectionLabel>
          <h1 className="font-display text-5xl font-bold uppercase leading-[1] tracking-tight sm:text-6xl">
            Servers that are <span className="text-gradient-badge">hiring</span>.
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-mute md:text-lg">
            Open staff roles and paid gigs from active Liberty County communities — apply
            straight through Discord.
          </p>

          <div className="mx-auto mt-9 max-w-2xl">
            <SearchBar
              value={query}
              onChange={setQuery}
              placeholder="Search by server or role"
              tags={FILTER_TAGS}
              activeTag={activeTag}
              onTagSelect={setActiveTag}
            />
          </div>
        </div>
      </section>

      <section className="relative border-t border-line py-16">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="font-display text-3xl font-bold uppercase tracking-tight">
            {filtered.length} open roles
          </h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2">
            {filtered.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
            {filtered.length === 0 && (
              <p className="col-span-full text-center text-sm text-mute">
                No openings match that search right now.
              </p>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
