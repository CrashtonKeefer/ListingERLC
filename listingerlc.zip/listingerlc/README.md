# ListingERLC

An original, production-ready directory site for Liberty County (ER:LC) roleplay
communities — built with Next.js 14 (App Router), TypeScript, Tailwind CSS,
Framer Motion, lucide-react, and NextAuth (Discord OAuth).

> This is an original design in the same genre as the reference screenshot
> (a Discord/Roblox server discovery + bump directory), not a copy of any
> specific third-party site's exact layout, branding, or copy.

## Three sections

- **Discover** (`/`) — search/filter, featured servers, trending, "New servers" sidebar, ad spot
- **People** (`/people`) — freelancers available for hire (builders, scripters, mods, designers, voice actors, community managers)
- **Hiring** (`/hiring`) — open staff roles and paid gigs posted by servers

All mock data lives in `lib/data.ts` — replace it with real listings whenever
you're ready (or wire it up to a database; see "Next steps" below).

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Discord sign-in

The "Sign in with Discord" button is wired to a real NextAuth.js + Discord
OAuth flow — it just needs your own Discord application credentials:

1. Go to https://discord.com/developers/applications → **New Application**
2. Under **OAuth2 → General**, copy the **Client ID** and **Client Secret**
3. Under **OAuth2 → Redirects**, add:
   - `http://localhost:3000/api/auth/callback/discord` (local dev)
   - `https://<your-deployed-domain>/api/auth/callback/discord` (production)
4. Copy `.env.example` to `.env.local` and fill in:
   ```
   DISCORD_CLIENT_ID=...
   DISCORD_CLIENT_SECRET=...
   NEXTAUTH_SECRET=...   # generate with: openssl rand -base64 32
   NEXTAUTH_URL=http://localhost:3000
   ```
5. On your host (Render/Vercel/etc.), set the same env vars in the dashboard,
   with `NEXTAUTH_URL` set to your real production URL.

Each server/job/person card's "Join Discord," "Apply via Discord," and
"Message on Discord" buttons currently point to a placeholder invite
(`https://discord.gg/replace-me`) — swap those for real invite links in
`lib/data.ts`.

## Project structure

```
app/
  layout.tsx              Root layout, fonts, AuthProvider
  page.tsx                 Discover (home)
  people/page.tsx          People directory
  hiring/page.tsx           Hiring directory
  api/auth/[...nextauth]/route.ts   Discord OAuth handler
  globals.css
components/
  Navbar.tsx                Discover/People/Hiring nav, scroll blur, Discord sign-in
  Footer.tsx
  ServerCard.tsx             Rating, members, tags, bump button, Join Discord / Play
  PersonCard.tsx             Freelancer profile card
  JobCard.tsx                Job posting card
  SearchBar.tsx              Search input + quick filter tags
  AdSpot.tsx                 Sponsored-listing promo banner
  AuthProvider.tsx           NextAuth SessionProvider wrapper
  ui/
    Button.tsx               primary / secondary / ghost / discord variants
    BumpButton.tsx            Client-side bump counter (resets on refresh — see Next steps)
    RatingStars.tsx
    SectionLabel.tsx
    Logo.tsx
lib/
  data.ts                   Mock servers / people / jobs
  auth.ts                    NextAuth config (Discord provider)
  utils.ts                    cn() helper
```

## Design notes

- **Palette**: near-black navy background with three accent colors pulled
  from emergency-services lighting — blue `#3B7BFF`, red `#FF4D5E`, amber
  `#FFB800` — plus green `#34D399` for "available/active" states.
- **Type**: Rajdhani (a dispatch-terminal–style condensed face) for
  headlines, Inter for body, JetBrains Mono for stats/codes/tags.
- Respects `prefers-reduced-motion`.

## Next steps (not included, since they need your own infrastructure)

- **Persistence**: bump counts, sign-ups, and listings are all in-memory mock
  data right now — nothing is saved. Wire up a database (Postgres, Supabase,
  etc.) to make listings and bumps persistent.
- **Submission flow**: there's no "add a server" form yet — the navbar button
  is a placeholder. Happy to build that next if useful.
- **Real Discord invites**: replace every `discord.gg/replace-me` in
  `lib/data.ts` with real invite URLs.

## Deploy

This repo's `package.json` lives at the **project root** — when you deploy
(Render, Vercel, etc.), make sure your **Root Directory** setting is empty /
points at the repo root, not a subfolder. On Render specifically:

- **Build Command**: `yarn && yarn build` (or `npm install && npm run build`)
- **Start Command**: `yarn start` (or `npm run start`)
- **Root Directory**: leave blank if this project's files sit at the repo root
