import { Users } from "lucide-react";
import { RatingStars } from "@/components/ui/RatingStars";
import { BumpButton } from "@/components/ui/BumpButton";
import type { Server } from "@/lib/data";
import { cn } from "@/lib/utils";

const ACCENT_BAR: Record<Server["accent"], string> = {
  blue: "from-accent-blue to-accent-green",
  red: "from-accent-red to-accent-amber",
  amber: "from-accent-amber to-accent-blue",
  green: "from-accent-green to-accent-blue",
};

export function ServerCard({ server }: { server: Server }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-line bg-panel/50 p-5 transition-colors hover:bg-panel2">
      <div className={cn("absolute inset-x-0 top-0 h-1 bg-gradient-to-r", ACCENT_BAR[server.accent])} />

      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className={cn(
              "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-line font-display text-sm font-bold uppercase",
              "bg-panel2 text-paper"
            )}
          >
            {server.tag}
          </div>
          <div>
            <h3 className="font-display text-lg font-bold leading-tight tracking-tight">{server.name}</h3>
            <div className="mt-0.5 flex items-center gap-3 text-xs text-mute">
              <RatingStars rating={server.rating} />
              <span className="inline-flex items-center gap-1">
                <Users size={12} />
                {server.members.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
        {server.badge && (
          <span
            className={cn(
              "shrink-0 rounded-full px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider",
              server.badge === "Featured" ? "bg-accent-amber/15 text-accent-amber" : "bg-accent-green/15 text-accent-green"
            )}
          >
            {server.badge}
          </span>
        )}
      </div>

      <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-mute">{server.description}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {server.tags.map((tag) => (
          <span key={tag} className="rounded-full border border-line px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-mute">
            {tag}
          </span>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between gap-2 border-t border-line pt-4">
        <BumpButton initialCount={server.bumps} />
        <div className="flex items-center gap-2">
          <a
            href={server.playUrl}
            className="rounded-full border border-line px-3 py-1.5 font-body text-xs font-semibold text-paper transition-colors hover:border-accent-green/50 hover:text-accent-green"
          >
            Play
          </a>
          <a
            href={server.discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-full bg-[#5865F2] px-3 py-1.5 font-body text-xs font-semibold text-white transition-colors hover:bg-[#4752C4]"
          >
            Join Discord
          </a>
        </div>
      </div>
    </div>
  );
}
