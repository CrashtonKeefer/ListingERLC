import Link from "next/link";
import { MessageCircle, Github, Globe } from "lucide-react";
import { Logo } from "@/components/ui/Logo";

export function Footer() {
  return (
    <footer className="relative border-t border-line py-16">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <Link href="/" className="flex items-center gap-2 text-paper">
              <Logo />
              <span className="font-display text-xl font-bold uppercase tracking-tight">
                ListingERLC
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-mute">
              The directory for Liberty County roleplay — discover servers, hire talent, and find
              your next staff role, all linked straight to Discord.
            </p>
            <div className="mt-6 flex items-center gap-4 text-mute">
              <a href="#" aria-label="Discord" className="transition-colors hover:text-paper">
                <MessageCircle size={18} />
              </a>
              <a href="#" aria-label="GitHub" className="transition-colors hover:text-paper">
                <Github size={18} />
              </a>
              <a href="#" aria-label="Website" className="transition-colors hover:text-paper">
                <Globe size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-mute">Browse</h4>
            <ul className="mt-4 flex flex-col gap-3 text-sm text-mute">
              <li><Link href="/" className="transition-colors hover:text-paper">Discover servers</Link></li>
              <li><Link href="/people" className="transition-colors hover:text-paper">Hire talent</Link></li>
              <li><Link href="/hiring" className="transition-colors hover:text-paper">Browse openings</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-mute">Resources</h4>
            <ul className="mt-4 flex flex-col gap-3 text-sm text-mute">
              <li><a href="#" className="transition-colors hover:text-paper">Submission guidelines</a></li>
              <li><a href="#" className="transition-colors hover:text-paper">Terms</a></li>
              <li><a href="#" className="transition-colors hover:text-paper">Privacy</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-line pt-8 sm:flex-row">
          <p className="font-mono text-xs text-mute">© {new Date().getFullYear()} ListingERLC.</p>
          <p className="font-mono text-xs text-mute">Not affiliated with Roblox Corporation or Discord Inc.</p>
        </div>
      </div>
    </footer>
  );
}
