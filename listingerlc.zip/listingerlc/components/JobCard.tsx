import { Button } from "@/components/ui/Button";
import type { Job } from "@/lib/data";
import { cn } from "@/lib/utils";

export function JobCard({ job }: { job: Job }) {
  return (
    <div className="group relative rounded-2xl border border-line bg-panel/50 p-5 transition-colors hover:bg-panel2">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-bold leading-tight tracking-tight">{job.role}</h3>
          <p className="mt-0.5 text-xs text-mute">{job.server} · {job.postedAgo}</p>
        </div>
        <span
          className={cn(
            "shrink-0 rounded-full px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider",
            job.type === "Paid" ? "bg-accent-amber/15 text-accent-amber" : "bg-accent-blue/15 text-accent-blue"
          )}
        >
          {job.type}
        </span>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-mute">{job.description}</p>

      <div className="mt-4 flex items-center justify-between border-t border-line pt-4">
        <span className="font-mono text-xs text-paper">{job.compensation}</span>
        <Button size="sm" variant="discord">
          Apply via Discord
        </Button>
      </div>
    </div>
  );
}
